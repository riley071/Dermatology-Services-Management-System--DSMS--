-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2025 at 01:17 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `edoc`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aemail` varchar(255) NOT NULL,
  `apassword` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aemail`, `apassword`) VALUES
('admin@edoc.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appoid` int(11) NOT NULL,
  `pid` int(10) DEFAULT NULL,
  `apponum` int(3) DEFAULT NULL,
  `status` text DEFAULT NULL,
  `scheduleid` int(10) DEFAULT NULL,
  `appodate` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`appoid`, `pid`, `apponum`, `status`, `scheduleid`, `appodate`) VALUES
(11, 2, 2, 'Pending', 18, '2022-11-08'),
(8, 3, 1, 'accpet', 15, '2022-11-04'),
(39, 17, 1, 'pending', 32, '2024-04-21'),
(25, 3, 1, 'pending', 21, '2022-11-18'),
(16, 3, 3, 'pending', 20, '2022-11-10'),
(17, 3, 4, 'pending', 20, '2022-11-10'),
(27, 3, 1, 'pending', 23, '2022-11-25'),
(38, 16, 3, 'pending', 30, '2023-11-30'),
(29, 9, 1, 'pending', 25, '2023-10-06'),
(30, 9, 2, 'pending', 25, '2023-10-06'),
(37, 11, 2, 'pending', 30, '2023-11-30'),
(33, 10, 1, 'pending', 27, '2023-10-18'),
(36, 11, 1, 'pending', 30, '2023-11-30'),
(35, 13, 2, 'pending', 29, '2023-11-29'),
(40, 11, 1, 'pending', 33, '2024-04-30');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `docid` int(11) NOT NULL,
  `docemail` varchar(255) DEFAULT NULL,
  `docname` varchar(255) DEFAULT NULL,
  `docpassword` varchar(255) DEFAULT NULL,
  `docnic` varchar(15) DEFAULT NULL,
  `doctel` varchar(15) DEFAULT NULL,
  `specialties` int(2) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`docid`, `docemail`, `docname`, `docpassword`, `docnic`, `doctel`, `specialties`) VALUES
(1, 'doctor@edoc.com', 'Test Doctor', '123', '000000000', '0110000000', 1),
(2, 'john@gmail.com', 'john', 'john', '12234', '2650998228829', 8),
(3, 'hazel@gmail.com', 'hazel', '123', '123', '09994565456', 7),
(4, 'pab@gmail.com', 'pab', '123', '256', '0712345671', 11),
(5, 'tmumba20@gmail.com', 'Tinashe', '123', '00000', '1245567890', 6);

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `pid` int(11) NOT NULL,
  `pemail` varchar(255) DEFAULT NULL,
  `pname` varchar(255) DEFAULT NULL,
  `ppassword` varchar(255) DEFAULT NULL,
  `paddress` varchar(255) DEFAULT NULL,
  `pnic` varchar(15) DEFAULT NULL,
  `pdob` date DEFAULT NULL,
  `ptel` varchar(15) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`pid`, `pemail`, `pname`, `ppassword`, `paddress`, `pnic`, `pdob`, `ptel`) VALUES
(1, 'patient@edoc.com', 'Test Patient', '123', 'Sri Lanka', '0000000000', '2000-01-01', '0120000000'),
(2, 'emhashenudara@gmail.com', 'Hashen Udara', '123', 'Sri Lanka', '0110000000', '2022-06-03', '0700000000'),
(12, 'b@gmail.com', 'bettie mumba', '123', 'limbe', '00000', '2023-11-02', '0999876543'),
(4, 'wngalu@gmail.com', 'Winston Ngalu', 'admin123', 'wngalu@gmail.com', '000684', '2002-03-18', '0993589726'),
(5, 'mama@gmail.com', 'joe mama', 'pass12345', 'mama@gmail.com', '1234567', '0078-03-09', '0728289292'),
(6, 'joe@gmail.com', 'mama joe', 'mama', 'blantyre', '12345678', '2022-11-24', '0728289292'),
(7, 'mike@gmail.com', 'Mike new', 'mike', 'Blantyre', '1234567', '2022-11-28', '0993589726'),
(8, 'tinashe@gmail.com', 'tinashe last name', '123', 'blantyer', '32940', '2023-09-19', '0997979773'),
(9, 'fantasiafiercee@gmail.com', 'nomsa mumba', '123', 'bt', '255', '2023-10-06', '0712345678'),
(10, 'steve@yahoo.com', 'Steve Awali', 'njanja', 'LL', '+265', '1901-03-09', '0909897676'),
(11, 'nm@gmail.com', 'nomsa mumba', '123', 'limbe', '00000', '2023-11-08', '0999876543'),
(13, 'new@gmail.com', 'new customer', '123', 'limbe', '00000', '2023-11-16', '0999876543'),
(14, 'new2@gmail.com', 'new  customer2', '123', 'limbe', '00000', '2023-12-06', '0999876543'),
(15, 'new3@gmail.com', 'new  customer2', '123', 'limbe', '00000', '2023-12-06', '0999876543'),
(16, 'asikiara@gmail.com', 'john banda', '123', 'limbe', '123', '2023-11-03', '0999876543'),
(17, 'j@gmail.com', 'jane mumba', '1234', 'limbe', '123', '1818-11-11', '0999876543');

-- --------------------------------------------------------

--
-- Table structure for table `patient_images`
--

CREATE TABLE `patient_images` (
  `image_id` int(11) NOT NULL,
  `pid` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `upload_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `qid` int(11) NOT NULL,
  `pid` varchar(255) DEFAULT NULL,
  `question1` text DEFAULT NULL,
  `question2` text DEFAULT NULL,
  `question3` text DEFAULT NULL,
  `question4` text DEFAULT NULL,
  `question6` text DEFAULT NULL,
  `question7` text DEFAULT NULL,
  `question5` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`qid`, `pid`, `question1`, `question2`, `question3`, `question4`, `question6`, `question7`, `question5`) VALUES
(31, '5', 'Prefer not to say', 'I feel Anxious or overwhelmed', 'Divorced', 'Individual (for myself)', 'Yes', 'No', '89'),
(30, '1', 'Straight', 'I feel Anxious or overwhelmed', 'Single', 'Couples (for myself and partner) ', 'Yes', 'Yes', '4'),
(29, '3', 'Straight', 'I have been feeling depressed', 'Single', 'Individual (for myself)', 'Yes', 'Yes', '4'),
(28, '3', 'Straight', 'I have been feeling depressed', 'Married', 'Individual (for myself)', 'Yes', 'Yes', '3'),
(25, '3', 'Straight', 'I have been feeling depressed', 'Single', 'Individual (for myself)', 'Yes', 'Yes', '2'),
(26, '1', 'Gay', 'I feel Anxious or overwhelmed', 'Married', 'Individual (for myself)', 'Yes', 'Yes', '7'),
(27, '2', 'Straight', 'I have been feeling depressed', 'Single', 'Couples (for myself and partner) ', 'Yes', 'Yes', '2'),
(32, '3', 'Straight', 'I have been feeling depressed', 'Married', 'Individual (for myself)', 'Yes', 'Yes', '12'),
(33, '7', 'Straight', 'I have been feeling depressed', 'Divorced', 'Individual (for myself)', 'Yes', 'Yes', '12');

-- --------------------------------------------------------

--
-- Table structure for table `questionnaire`
--

CREATE TABLE `questionnaire` (
  `ID` int(11) NOT NULL,
  `Question 1` text NOT NULL,
  `Question 2` text NOT NULL,
  `Question 3` text NOT NULL,
  `Question 4` text NOT NULL,
  `Question 5` text NOT NULL,
  `Question 6` text NOT NULL,
  `Question 7` text NOT NULL,
  `Question 8` text NOT NULL,
  `Question 9` text NOT NULL,
  `Question 10` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `questionnaire`
--

INSERT INTO `questionnaire` (`ID`, `Question 1`, `Question 2`, `Question 3`, `Question 4`, `Question 5`, `Question 6`, `Question 7`, `Question 8`, `Question 9`, `Question 10`) VALUES
(1, 'Straight', 'I feel Anxious or overwhelmed', 'Single', 'Woman', 'Individual (for myself)', 'Yes', 'Judaism', 'Yes', 'Yes', 'Proactively checks in with me'),
(2, 'Straight', 'I have been feeling depressed', 'Married', 'Man', 'Individual (for myself)', 'Yes', 'Christianity', 'Yes', 'Yes', 'Teaches me new skills'),
(3, 'Straight', 'I am grieving', 'Married', 'Man', 'Individual (for myself)', 'Yes', 'Christianity', 'Yes', 'Yes', 'Assigns me work');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `scheduleid` int(11) NOT NULL,
  `docid` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `scheduledate` date DEFAULT NULL,
  `scheduletime` time DEFAULT NULL,
  `nop` int(4) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`scheduleid`, `docid`, `title`, `scheduledate`, `scheduletime`, `nop`) VALUES
(11, '1', 'Skin Examinations:', '2022-10-31', '21:03:00', 4),
(10, '1', 'Skin Cancer Screening', '2022-10-26', '13:02:00', 9),
(15, '1', 'Acne Treatment', '2022-11-04', '23:04:00', 3),
(9, '1', 'Acne Treatment', '2022-07-26', '14:10:00', 1),
(13, '1', 'Eczema and Dermatitis Care', '2022-10-28', '01:02:00', 2),
(21, '1', 'Hair and Scalp Disorders', '2022-11-18', '20:30:00', 8),
(22, '1', 'Skin Allergy Testing', '2022-11-24', '06:17:00', 2),
(23, '1', 'Skin Allergy Testing', '2022-11-25', '06:07:00', 4),
(31, '1', 'medical', '2023-12-09', '07:46:00', 2),
(32, '1', 'Skin rush', '2024-04-23', '03:07:00', 2),
(26, '1', 'medical', '2023-10-20', '17:45:00', 4),
(27, '4', 'medical', '2023-10-21', '05:46:00', 2),
(28, '4', 'Skin1', '2023-10-18', '14:43:00', 4),
(30, '1', 'med', '2023-12-02', '17:20:00', 3),
(33, '1', 'face', '2024-05-11', '21:10:00', 5);

-- --------------------------------------------------------

--
-- Table structure for table `specialties`
--

CREATE TABLE `specialties` (
  `id` int(2) NOT NULL,
  `sname` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `specialties`
--

INSERT INTO `specialties` (`id`, `sname`) VALUES
(1, 'Medical Dermatology'),
(2, 'Surgical Dermatology'),
(3, 'Pediatric Dermatology'),
(4, 'Dermatopathology'),
(5, 'Cosmetic Dermatology'),
(6, 'Dermatologic Surgery'),
(7, 'Teledermatology'),
(8, 'Hair Disorders (Trichology)'),
(9, 'Sexual Health and Dermatology'),
(10, 'Medical Dermatology'),
(11, 'Medical Dermatology');

-- --------------------------------------------------------

--
-- Table structure for table `treatment`
--

CREATE TABLE `treatment` (
  `tid` int(11) NOT NULL,
  `pid` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `medication` varchar(255) DEFAULT NULL,
  `nop` int(4) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `treatment`
--

INSERT INTO `treatment` (`tid`, `pid`, `type`, `medication`, `nop`, `title`) VALUES
(15, '7', 'ecezma treatment', 'none', 12, 'pyscholo therapy'),
(3, '1', 'Allergic reactions', 'sjsjsjs', 1, '12'),
(14, '2', 'Acne', 'w', 11, 'snsnns'),
(13, '4', 'Skin discoloration', 'jsjjs', 12, 'aaaaaaaaaaa'),
(6, '1', 'Skin Cancer', 'sjsjsjs', 1, '12'),
(7, '1', 'Sunburn / sunspots', 'sjsjsjs', 1, '1'),
(16, '16', 'medical', 'skin rubs', 2, 'medical eczema'),
(9, '3', 'Yeast infection', 'aaaaaaa', 1, 'qqqqqqqqqqqqq'),
(10, '3', 'treatment', 'none', 12, 'couple therapy'),
(11, '3', 'Dandruff', 'assssssssss', 1, 'aaaaaaaaaaa'),
(12, '3', 'appointment invitation', 'none', 1, 'couple treatment'),
(17, '17', 'cream ontiment', 'medication number 1', 1, 'rush infection');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `amount` decimal(10,2) DEFAULT 0.00,
  `status` varchar(50) DEFAULT 'Active',
  `comment` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `phone`, `email`, `amount`, `status`, `comment`, `created_at`, `updated_at`) VALUES
(47, 'ffffffffffffffffff', '000000000', 'emm@gmail.com', 50.00, 'pending', 'ccccc', '2023-11-26 22:21:25', '2023-11-26 22:21:25'),
(48, 'Tinashe', '9957757', 'tmumba20@gmail.com', 100.00, 'completed', 'payment for appointment ', '2023-11-27 11:37:01', '2023-11-27 11:40:25'),
(49, 'Tinashe', '9957757', 'tmumba20@gmail.com', 100.00, 'completed', 'my appointment payment', '2023-11-29 12:49:57', '2023-11-29 12:53:31'),
(50, 'john', '12', 'asikiara@gmail.com', 100.00, 'pending', 'm', '2023-11-30 12:49:09', '2023-11-30 12:49:09'),
(51, 'r', '12', 'tmumba20@gmail.com', 100.00, 'pending', 'e', '2023-11-30 12:52:24', '2023-11-30 12:52:24');

-- --------------------------------------------------------

--
-- Table structure for table `webuser`
--

CREATE TABLE `webuser` (
  `email` varchar(255) NOT NULL,
  `usertype` char(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `webuser`
--

INSERT INTO `webuser` (`email`, `usertype`) VALUES
('admin@edoc.com', 'a'),
('doctor@edoc.com', 'd'),
('patient@edoc.com', 'p'),
('emhashenudara@gmail.com', 'p'),
('emzo@gmail.com', 'p'),
('wngalu@gmail.com', 'p'),
('john@gmail.com', 'd'),
('mama@gmail', 'p'),
('joe@gmail.com', 'p'),
('mike@gmail.com', 'p'),
('tinashe@gmail.com', 'p'),
('hazel@gmail.com', 'd'),
('fantasiafiercee@gmail.com', 'p'),
('pab@gmail.com', 'd'),
('steve@yahoo.com', 'p'),
('nm@gmail.com', 'p'),
('b@gmail.com', 'p'),
('new@gmail.com', 'p'),
('new2@gmail.com', 'p'),
('new3@gmail.com', 'p'),
('tmumba20@gmail.com', 'd'),
('asikiara@gmail.com', 'p'),
('j@gmail.com', 'p');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aemail`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appoid`),
  ADD KEY `pid` (`pid`),
  ADD KEY `scheduleid` (`scheduleid`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`docid`),
  ADD KEY `specialties` (`specialties`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `patient_images`
--
ALTER TABLE `patient_images`
  ADD PRIMARY KEY (`image_id`),
  ADD KEY `pid` (`pid`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`qid`),
  ADD KEY `pid` (`pid`);

--
-- Indexes for table `questionnaire`
--
ALTER TABLE `questionnaire`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`scheduleid`),
  ADD KEY `docid` (`docid`);

--
-- Indexes for table `specialties`
--
ALTER TABLE `specialties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `treatment`
--
ALTER TABLE `treatment`
  ADD PRIMARY KEY (`tid`),
  ADD KEY `pid` (`pid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `webuser`
--
ALTER TABLE `webuser`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `appoid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `docid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `patient_images`
--
ALTER TABLE `patient_images`
  MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `qid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `questionnaire`
--
ALTER TABLE `questionnaire`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `scheduleid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `treatment`
--
ALTER TABLE `treatment`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
